// Задание 1
// 1.1
for index in 1...100 {
    print(index)
}
 
// 1.2
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
for (i, letter) in alphabet.enumerated() {
    print("\(i): \(letter)")
}



